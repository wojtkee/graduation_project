


-----------------------------------------------------------------
The following information has automatically been added by CoDeSys provided by Festo
-----------------------------------------------------------------
Version: CoDeSys provided by Festo Version 2.3.9.42 (Build Oct 14 2013)
